namespace DAL;
using BOL;

public class DBManager{

     public List<Product> GetAllProd()
    {
        using (var context = new CollectionContext())
        {
            var products=from prod in context.Product select prod;
            return products.ToList<Product>();
        }
    }

   
}