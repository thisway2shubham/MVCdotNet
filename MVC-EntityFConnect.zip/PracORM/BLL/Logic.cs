﻿namespace BLL;

using BOL;
using DAL;
public class Logic
{
     public List<Product> productsList(){
        
        List<Product> list=new List<Product>();
        DBManager mgr=new DBManager();
        list =mgr.GetAllProd();
        foreach (Product item in list)
        {
            Console.WriteLine(item.pname);
            Console.WriteLine(item.pid);
            Console.WriteLine(item.price);
            Console.WriteLine(item.stock);
        }
        return list;
     }
}
