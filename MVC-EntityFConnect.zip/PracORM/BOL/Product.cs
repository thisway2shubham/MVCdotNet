﻿namespace BOL;
public class Product
{
    public int pid{get;set;}

    public String pname{get;set;}

    public int stock{get;set;}

    public double price{get;set;}

}
