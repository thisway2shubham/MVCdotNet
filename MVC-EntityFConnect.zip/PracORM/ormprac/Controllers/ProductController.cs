using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ormprac.Models;
using BOL;
using BLL;

namespace ormprac.Controllers;

public class ProductController : Controller
{
    private readonly ILogger<ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<Product> products=new List<Product>();
        Logic logic=new Logic();

        products=logic.productsList();
        // this.ViewData["products"]=products;
            ViewBag.shubhu=products;

        // foreach (Product item in products)
        // {
        //     Console.WriteLine(item.pname);
        // }
        return View();
    }
 

}
